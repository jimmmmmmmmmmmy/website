from django.views.generic import *

from . import controllers
from .base import *
from .changelist import *
from .detail import *
from .edit import *
from .list import *
